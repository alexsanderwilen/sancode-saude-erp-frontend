﻿export interface Acomodacao {
  id: number;
  descricao: string;
}


