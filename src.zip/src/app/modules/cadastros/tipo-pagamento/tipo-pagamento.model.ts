﻿export interface TipoPagamento {
  id: number;
  descricao: string;
}


