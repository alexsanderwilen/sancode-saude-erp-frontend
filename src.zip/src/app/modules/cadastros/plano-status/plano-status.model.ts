﻿export interface PlanoStatus {
  id: number;
  descricao: string;
}

