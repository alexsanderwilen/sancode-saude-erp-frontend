﻿export interface TipoContratacao {
  id: number;
  descricao: string;
}

