﻿export interface TipoPlano {
  id: number;
  descricao: string;
  descricaoAns?: string;
  observacoesPraticas?: string;
}


