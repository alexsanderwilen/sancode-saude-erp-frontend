﻿export interface CoberturaAdicional {
  id: number;
  descricao: string;
  descricaoDetalhada?: string;
  tipo?: string;
  obrigatoriaAns?: boolean;
}



