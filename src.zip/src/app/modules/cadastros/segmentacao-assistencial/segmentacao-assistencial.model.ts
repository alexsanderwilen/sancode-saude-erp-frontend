﻿export interface SegmentacaoAssistencial {
  id: number;
  descricao: string;
}

