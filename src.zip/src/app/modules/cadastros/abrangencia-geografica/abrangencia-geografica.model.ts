﻿export interface AbrangenciaGeografica {
  id: number;
  descricao: string;
}

