﻿import { Component } from '@angular/core';

@Component({
  selector: 'app-usuario-home',
  standalone: true,
  imports: [],
  templateUrl: './usuario-home.component.html',
  styleUrls: ['./usuario-home.component.scss']
})
export class UsuarioHomeComponent {

}

