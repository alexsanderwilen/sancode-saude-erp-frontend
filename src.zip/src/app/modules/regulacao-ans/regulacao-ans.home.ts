import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-regulacao-ans-home',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './regulacao-ans.home.html',
  styleUrls: ['./regulacao-ans.home.css']
})
export class RegulacaoAnsHomeComponent {}

